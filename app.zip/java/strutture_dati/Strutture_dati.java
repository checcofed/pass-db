package strutture_dati;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface Strutture_dati {
    @Override
    public String toString();
    
    public Strutture_dati traduci(String attributi,ResultSet risQuery)throws SQLException;
    public String insert();
    public String update(String attrModificato,String newValue,String conditions);
}
