import entity.Entity;
import entity.Funzioni;
import interfaccia_utente.Utente;

public class App {
    public static Entity inizioEsec(){
        boolean errore=true;
        Entity myEntity=null;

        while (errore){
            errore=false;
            System.out.println("Premi 1 per accedere, premi 2 per registrarti, premi 0 per uscire");
            String scelta=Utente.input();

            if(scelta.equals("1")){
                myEntity=Funzioni.accesso();
                if (myEntity==null){
                    errore=true;
                    System.err.println("Errore, username o password errati, riprova");
                }
            }
            else if(scelta.equals("2")){
                myEntity=Funzioni.registrazione();
                if (myEntity==null){
                        errore=true;
                        System.err.println("Errore, non è possibile completare la registrazione, riprova");
                    }
            }
            else if(scelta.equals("0")){
                continue;
            }
            else{
                System.out.println("Errore, valore inserito non valido, riprova");
                errore=true;
            }
        }
        System.out.println("operazione eseguita con successo");
        return myEntity;
    }
    
    public static void sceltaUtente(Entity myself){
        boolean fine=false;
        while (!fine){
            
            System.out.println("Cosa vuoi fare?\n1.INSERT\n2.UPDATE\n3.SELECT\n4.DELETE\n0. ESCI");
            String scelta=Utente.input();

            if(scelta.equals("1")){
                Funzioni.insert(myself);
            }
            else if(scelta.equals("2")){
                Funzioni.update(myself);
            }
            else if(scelta.equals("3")){
                Funzioni.select(myself);
            }
            else if(scelta.equals("4")){
                Funzioni.delete(myself);
            }
            else if(scelta.equals("0")){
                fine=true;
            }
            else{
                System.out.println("Errore, valore inserito non valido, riprova");
            }
            
        }

    }
    
    public static void main(String[] args) throws Exception {
               
        Entity nuovo=inizioEsec();
        if (nuovo!=null){
            sceltaUtente(nuovo);
        }
        
    }
}
