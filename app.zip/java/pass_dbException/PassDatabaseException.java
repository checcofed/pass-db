package pass_dbException;

public class PassDatabaseException extends PassException {
    public PassDatabaseException(String SQLError){
        super(SQLError);
    }
}
