package pass_dbException;

public class PassException extends Throwable{
    public PassException(String msgError){
        super(msgError);
    }    
}
