package pass_dbException;

public class PrivilegeException extends PassException {
    public PrivilegeException(){
        super("errore, nome invalido o non si possiedono i privilegi per modificare la tabella");
    }
    
}
