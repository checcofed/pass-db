package entity;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import connessione_db.DBConnectionManager;
import pass_dbException.PassDatabaseException;
import pass_dbException.PassException;
import strutture_dati.Automobili;
import strutture_dati.Carte;
import strutture_dati.Caselli;
import strutture_dati.Clienti;
import strutture_dati.Conti;
import strutture_dati.Dispositivi;
import strutture_dati.Statistica;
import strutture_dati.Strutture_dati;
import strutture_dati.Tragitti;

public class Entity {
    protected DBConnectionManager myManager;

    public Entity(String username,String password){
        myManager=new DBConnectionManager(username, password);
    }
    
    private Strutture_dati[] crea_struttura(ResultSet risQuery,String tabella,String attributi)throws SQLException{
        tabella=tabella.toLowerCase();
        Strutture_dati[] risultato=null;
        Strutture_dati[]buffer=risultato;
        
        int cont=0;  
            
        while(risQuery.next()){
            
            if(tabella.equals("dispositivi")){
                risultato=new Dispositivi[cont+1];
                risultato[cont]=new Dispositivi();
            }
            else if(tabella.equals("clienti")){
                risultato=new Clienti[cont+1];
                risultato[cont]=new Clienti();
            }
            else if(tabella.equals("caselli")){
                risultato=new Caselli[cont+1];
                risultato[cont]=new Caselli();
            }
            else if(tabella.equals("tragitti")){
                risultato=new Tragitti[cont+1];
                risultato[cont]=new Tragitti();
            }
            else if(tabella.equals("automobili")){
                risultato=new Automobili[cont+1];
                risultato[cont]=new Automobili();
            }
            else if(tabella.equals("carte")){
                risultato=new Carte[cont+1];
                risultato[cont]=new Carte();
            }
            else if(tabella.equals("conti")){
                risultato=new Conti[cont+1];
                risultato[cont]=new Conti();
            }
            
            for (int i=0;i<cont;i++){
                risultato[i]=buffer[i];
            }
            
            risultato[cont].traduci(attributi,risQuery);
            buffer=risultato;
            cont++;
        }
    
        return risultato;
    }

    public int create(Amministratore amm,String tabella)throws PassException{
        return amm.create(tabella);
    }
    public int update(Amministratore amm,String tabella,String attributiModificati,String nuoviValori,String conditions) throws PassException{
        return amm.update(tabella,attributiModificati,nuoviValori,conditions);
    }
    
    public Strutture_dati[] read(String tabella,String attributi,String condizioni) throws PassException{
        String query=null;
        ResultSet risQuery=null;
        Strutture_dati[] result=null;
        
        if(tabella.equals("dati statistici")||tabella.equals("statistica")){
            result=new Statistica[3];
            try {
                Connection conn=myManager.getConnection();
                for (int i=0;i<3;i++){
                    String attr="";
                    if(i==0){
                        query="select count(*) from tragitti where nomeCaselloUscita is null";
                        attr="tragitti_in_corso";
                    }
                    else if(i==1){
                        query="select dispositivoIndividuato,1.10*COUNT(*) FROM TRAGITTI WHERE NOMECASELLOUSCITA IS NOT NULL GROUP BY(dispositivoIndividuato)";
                        attr="fattura";
                    }
                    else{
                        query="select orario_piu_trafficato()";
                        attr="orario_piu_trafficato";
                    } 

                    risQuery=myManager.selectQuery(query,conn);
                    result[i]=new Statistica();
                    result[i].traduci(attr, risQuery);
                }
                
                myManager.closeConnection(conn);
            } catch (SQLException e) {
                throw (new PassDatabaseException(e.toString()));
            }
            catch(ClassNotFoundException e){
                throw (new PassDatabaseException(e.toString()));
            }
        }
        else{
            query="select ";
            if (attributi==null)query+="* from "+tabella;
            else {
                String[] attributi_list=attributi.split(" ");
                for(int i=0;i<attributi_list.length;i++){
                    query+=attributi_list[i];
                    if(i==attributi_list.length-1)query+=" from "+tabella;
                    else query+=",";
                }
            }

            if(condizioni!=null)query+=" where "+condizioni;

            try {
                Connection conn=myManager.getConnection();
                
                risQuery=myManager.selectQuery(query,conn);
                result=crea_struttura(risQuery,tabella,attributi);
                myManager.closeConnection(conn);
            } catch (SQLException e) {
                throw (new PassDatabaseException(e.toString()));
            }
            catch(ClassNotFoundException e){
                throw (new PassDatabaseException(e.toString()));
            }
        }
        
        return result;
    }
    public int delete(Amministratore amm,String tabella,String condizioni) throws PassException{
        return amm.delete(tabella,condizioni);
    }

    public boolean verify() throws PassException{
        boolean ris=false;
        try{
            Connection conn=myManager.getConnection();
            
            ris=myManager.test(conn);
            myManager.closeConnection(conn);
            
        }
        catch (SQLException e) {
            throw (new PassDatabaseException(e.toString()));
        }
        catch(ClassNotFoundException e){
            throw (new PassDatabaseException(e.toString()));
        }
        
        return ris;
    }
}
