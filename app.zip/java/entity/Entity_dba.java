package entity;

import java.sql.Connection;
import java.sql.SQLException;

import pass_dbException.PassDatabaseException;
import pass_dbException.PassException;

public class Entity_dba extends Entity {
    public Entity_dba(String username,String password){
        super(username,password);
    }
    
    public int create_user(String username,String password)throws PassException{
        int ris=-1;
        try{
            Connection conn=myManager.getConnection();
            
            myManager.updateQuery("create user "+username+" identified by '"+password+"'",conn);
            myManager.updateQuery("grant select on pass_db.* to "+username, conn);
            myManager.updateQuery("GRANT EXECUTE ON FUNCTION pass_db.orario_piu_trafficato TO "+username, conn);

            myManager.closeConnection(conn);
            ris=0;
        }
        catch(SQLException e){
                throw(new PassDatabaseException(e.toString()));
        }
        catch(ClassNotFoundException e){
            throw(new PassDatabaseException(e.toString()));
        }
        return ris;
    }
    
    public int delete_user(String username) throws PassException{
        String query="drop user "+username;
        int ris=-1;
        try{
            Connection conn=myManager.getConnection();
            
            myManager.updateQuery(query, conn);

            myManager.closeConnection(conn);
            ris=0;
        }
        catch(SQLException e){
            throw(new PassDatabaseException(e.toString()));
        }
        catch(ClassNotFoundException e){
            throw(new PassDatabaseException(e.toString()));
        }
        return ris;
    }
}
