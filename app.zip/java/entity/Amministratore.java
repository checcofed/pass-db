package entity;

import java.sql.Connection;
import java.sql.SQLException;

import connessione_db.DBConnectionManager;
import pass_dbException.PassDatabaseException;
import pass_dbException.PassException;
import pass_dbException.PrivilegeException;
import strutture_dati.Automobili;
import strutture_dati.Carte;
import strutture_dati.Clienti;
import strutture_dati.Conti;
import strutture_dati.Dispositivi;
import strutture_dati.Strutture_dati;
import strutture_dati.Tragitti;

public class Amministratore {
    private DBConnectionManager man;

    public Amministratore(String password) {
        man=new DBConnectionManager("ADMINISTRATOR_DBPASS", password);
    }

    public boolean autorizza(){
        boolean risultato;

        try {
            Connection c=man.getConnection();
            man.test(c);
            man.closeConnection(c);
            risultato=true;
        } catch (ClassNotFoundException e) {
            risultato=false;
        } catch (SQLException e) {
            risultato=false;
        }

        return risultato;
    } 
    public int create(String tabella)throws PassException{
        Strutture_dati nuova=null;
        String query=null;
        int rowUpdated=-1;
        if(tabella.equals("automobili")){
            nuova=new Automobili();
        }
        else if(tabella.equals("dispositivi")){
            nuova=new Dispositivi();
        }
        else if(tabella.equals("tragitti")){
            nuova=new Tragitti();
        }
        else if(tabella.equals("clienti")){
            nuova=new Clienti();
        }
        else{
            throw(new PrivilegeException());
        }
        if(nuova!=null){
            query=nuova.insert();

            try {
            Connection conn=man.getConnection();
            rowUpdated=man.updateQuery(query, conn);
            man.closeConnection(conn);
            } catch (SQLException e) {
                throw(new PassDatabaseException(e.toString()));
            }
            catch(ClassNotFoundException e){
                throw(new PassDatabaseException(e.toString()));
            }
        }
        return rowUpdated;
    } 
    public int update(String tabella,String attributoModificato,String value,String conditions) throws PassException{
        int rowsUpdated=-1;
        Strutture_dati strutturaModificata=null;
        String query=null;

        if(tabella.equals("clienti")){
            strutturaModificata=new Clienti();
        }
        else if(tabella.equals("automobili")){
            strutturaModificata=new Automobili();
        }
        else if(tabella.equals("conti")){
            strutturaModificata=new Conti();
        }
        else if(tabella.equals("carte")){
            strutturaModificata=new Carte();
        }
        else if(tabella.equals("dispositivi")){
            strutturaModificata=new Dispositivi();
        }
        else{
            throw (new PrivilegeException()); 
        }
        
        query=strutturaModificata.update(attributoModificato, value, conditions);
        try {
            Connection conn = man.getConnection();
            rowsUpdated=man.updateQuery(query, conn);
            man.closeConnection(conn);
        } catch (ClassNotFoundException e) {
            throw(new PassDatabaseException(e.toString()));
        } catch (SQLException e) {
            throw(new PassDatabaseException(e.toString()));
        }
        
        return rowsUpdated;
    }
    public int delete(String tabella,String condizioni) throws PassException{
        if(!tabella.equals("automobili")&&!tabella.equals("dispositivi")&&!tabella.equals("clienti")
        &&!tabella.equals("carte")&&!tabella.equals("conti")) throw(new PrivilegeException());
        int rowsUpdated=-1;
        String query="delete from "+tabella+" where "+condizioni;
        
        try {
            Connection conn=man.getConnection();
            rowsUpdated=man.updateQuery(query, conn);
            man.closeConnection(conn);
            
        } catch (SQLException e) {
            throw(new PassDatabaseException(e.toString()));
        }catch(ClassNotFoundException e){
            throw(new PassDatabaseException(e.toString()));
        }

        return rowsUpdated;
    }  
}
