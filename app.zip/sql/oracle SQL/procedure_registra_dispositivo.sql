CREATE OR REPLACE PROCEDURE REGISTRA_DISPOSITIVO( 
    codFiscaleInteressato IN CLIENTI.CF%TYPE, 
    targaAuto IN AUTOMOBILI.TARGA%TYPE, 
    modelloAuto IN AUTOMOBILI.MODELLO%TYPE 
) 
AS 
BEGIN  
	DECLARE 
	nuovo_dispositivo INTEGER; 
	buffer VARCHAR(10); 
	CURSOR auto_cursor IS SELECT targa FROM AUTOMOBILI WHERE targaAuto=targa; 
    
BEGIN 
    SELECT MAX(codice)+1 INTO nuovo_dispositivo FROM DISPOSITIVI; 
	INSERT INTO DISPOSITIVI VALUES (nuovo_dispositivo); 
	
	OPEN auto_cursor; 
	FETCH auto_cursor INTO buffer; 
 
	IF auto_cursor%ROWCOUNT=0 THEN 
		INSERT INTO AUTOMOBILI VALUES(targaAuto,modelloAuto,codFiscaleInteressato,nuovo_dispositivo); 
	ELSE 
        UPDATE AUTOMOBILI SET dispositivo=nuovo_dispositivo WHERE targa=targaAuto; 
	END IF; 
 
	COMMIT; 
	CLOSE auto_cursor;	 
	EXCEPTION 
        WHEN NO_DATA_FOUND THEN nuovo_dispositivo:=1; 
	 
	END; 
END REGISTRA_DISPOSITIVO;
