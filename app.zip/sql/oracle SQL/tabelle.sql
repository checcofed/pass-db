CREATE TABLE DISPOSITIVI(   
    codice INTEGER, 
    CONSTRAINT PK_DISPOSITIVI PRIMARY KEY(codice)   
);

CREATE TABLE CASELLI(   
    uscitaAutostradale VARCHAR(40),   
    numero INTEGER,   
    CONSTRAINT PK_CASELLI PRIMARY KEY(uscitaAutostradale,numero)   
);

CREATE TABLE TRAGITTI(     
    dispositivoIndividuato INTEGER,     
    numero INTEGER,     
    nomeCaselloIngresso VARCHAR(40) NOT NULL,      
    numeroCaselloIngresso INTEGER NOT NULL,     
    data_ora_ingresso TIMESTAMP NOT NULL,   
    nomeCaselloUscita VARCHAR(40),      
    numeroCaselloUscita INTEGER,     
    data_ora_uscita TIMESTAMP,    
    CONSTRAINT CHK_CONSISTENZA_USCITA CHECK( 
(nomeCaselloUscita IS NULL AND numeroCaselloUscita IS NULL AND data_ora_uscita IS NULL) OR 
(nomeCaselloUscita IS NOT NULL AND numeroCaselloUscita IS NOT NULL AND data_ora_uscita IS NOT NULL) 
), 
    CONSTRAINT CHK_USCITA_VALIDA CHECK(data_ora_ingresso<data_ora_uscita), 
    CONSTRAINT PK_TRAGITTI PRIMARY KEY(dispositivoIndividuato,numero)    
);

CREATE TABLE AUTOMOBILI (  
    targa VARCHAR(10),   
    modello VARCHAR(30) NOT NULL,   
    proprietario VARCHAR(16), 
    dispositivo INTEGER NOT NULL,  
    CONSTRAINT PK_AUTOMOBILI PRIMARY KEY(targa)  
);

CREATE TABLE CLIENTI (   
    CF VARCHAR(16),    
    nome VARCHAR(30) NOT NULL,    
    cognome VARCHAR(30) NOT NULL,    
    dataNascita DATE NOT NULL,    
    CONSTRAINT CHK_LUNGHEZZA_CF CHECK(LENGTH(CF)=16), 
    CONSTRAINT PK_CLIENTI PRIMARY KEY (CF)  
);

CREATE TABLE CARTE (   
    codiceCarta INTEGER,    
    scadenza DATE NOT NULL,  
    CVV INTEGER NOT NULL, 
    proprietarioCarta VARCHAR(16) UNIQUE NOT NULL, 
    CONSTRAINT CHK_VALIDITA_CVV CHECK(CVV>=0 AND CVV<=999), 
    CONSTRAINT PK_CARTE PRIMARY KEY (codiceCarta)   
);

CREATE TABLE CONTI (   
    codiceConto INTEGER,    
    IBAN VARCHAR(27) UNIQUE NOT NULL, 
    proprietarioConto VARCHAR(16) UNIQUE NOT NULL,    
    CONSTRAINT CHK_LUNGHEZZA_IBAN CHECK(LENGTH(IBAN)=27), 
    CONSTRAINT PK_CONTI PRIMARY KEY(codiceConto)      
);