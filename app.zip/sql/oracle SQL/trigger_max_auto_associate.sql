CREATE OR REPLACE TRIGGER MAX_AUTO_ASSOCIATE   
BEFORE INSERT OR UPDATE ON AUTOMOBILI   
FOR EACH ROW   
   
DECLARE 
max_auto_raggiunto exception;   
num_dispositivi integer:=0;   
   
BEGIN   
select numero_automobili into num_dispositivi from CONTA_AUTOMOBILI where :new.dispositivo=conta_automobili.codice;   
if num_dispositivi=2 then raise max_auto_raggiunto;   
end if;   
   
EXCEPTION   
WHEN NO_DATA_FOUND THEN num_dispositivi:=0;
when max_auto_raggiunto then raise_application_error(-20001,'il dispositivo ha già associate a se due automobili, operazione negata');   
end;  