CREATE OR REPLACE FUNCTION ORARIO_PIU_TRAFFICATO 
RETURN CHAR 
IS 
BEGIN 
	DECLARE 
	orario_ingresso CHAR(4); 
	numero_ingressi INTEGER; 
	orario_uscita CHAR(4); 
	numero_uscite INTEGER; 
    BEGIN 
 
    SELECT MAX(COUNT(*)) 
        INTO numero_ingressi 
        FROM TRAGITTI  
        GROUP BY(CONCAT(SUBSTR(data_ora_ingresso,11,2),SUBSTR(data_ora_ingresso,27,2))); 
	 
         
    SELECT CONCAT(SUBSTR(data_ora_ingresso,11,2),SUBSTR(data_ora_ingresso,27,2)) INTO orario_ingresso 
    FROM TRAGITTI  
    GROUP BY (CONCAT(SUBSTR(data_ora_ingresso,11,2),SUBSTR(data_ora_ingresso,27,2)))  
    HAVING COUNT(*)=numero_ingressi; 
 
	SELECT MAX(COUNT(*)) 
        INTO numero_uscite 
        FROM TRAGITTI 
        WHERE data_ora_uscita IS NOT NULL 
        GROUP BY(CONCAT(SUBSTR(data_ora_uscita,11,2),SUBSTR(data_ora_uscita,27,2))); 
 
	SELECT CONCAT(SUBSTR(data_ora_uscita,11,2),SUBSTR(data_ora_uscita,27,2)) INTO orario_uscita 
    FROM TRAGITTI  
    GROUP BY (CONCAT(SUBSTR(data_ora_uscita,11,2),SUBSTR(data_ora_uscita,27,2)))  
    HAVING COUNT(*)=numero_uscite; 
 
	IF numero_ingressi>numero_uscite THEN 
		RETURN orario_ingresso; 
	ELSE 
		RETURN orario_uscita; 
	END IF; 
	 
    END; 
END ORARIO_PIU_TRAFFICATO;
