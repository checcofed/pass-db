CREATE OR REPLACE TRIGGER CLIENTE_DUPLICATO_CARTA  
BEFORE INSERT OR UPDATE ON CONTI    
FOR EACH ROW   
DECLARE   
CURSOR cf_cursor IS SELECT CF FROM CLIENTI_CON_CARTA;  
bufferCF CLIENTI.CF%TYPE;  
BEGIN   
OPEN cf_cursor;  
  
LOOP  
    FETCH cf_cursor INTO bufferCF;  
	IF :new.proprietarioconto=bufferCF THEN   
        CLOSE cf_cursor;  
        RAISE_APPLICATION_ERROR(-20004,'cliente ha indicato una carta come metodo di pagamento!');  
	END IF;   
	  
	EXIT WHEN cf_cursor %notfound;  
	END LOOP;  
  
CLOSE cf_cursor;  
END; 
