CREATE OR REPLACE PROCEDURE INSERISCI_DATI_CLIENTE(  
    cf IN CLIENTI.CF%TYPE,   
    nome IN CLIENTI.nome%TYPE,   
	cognome IN CLIENTI.cognome %TYPE,   
    datanascita IN CLIENTI.datanascita%TYPE,   
    codiceMetodoPagamento IN INTEGER,   
    IBAN IN CONTI.IBAN%TYPE,   
    scadenza IN CARTE.scadenza%TYPE,   
    CVV IN CARTE.CVV%TYPE   
) IS  
BEGIN  
	DECLARE  
    pagamento_invalido EXCEPTION; 
	 
    BEGIN  
    IF IBAN IS NULL AND scadenza IS NOT NULL AND CVV IS NOT NULL THEN 
        INSERT INTO CLIENTI VALUES(cf,nome,cognome,datanascita); 
		INSERT INTO CARTE VALUES(codiceMetodoPagamento,scadenza,CVV,cf); 
		COMMIT;      
    ELSE  
        IF IBAN IS NOT NULL AND scadenza IS NULL AND CVV IS NULL THEN 
        	INSERT INTO CLIENTI VALUES(cf,nome,cognome,datanascita); 
        	INSERT INTO CONTI VALUES(codiceMetodoPagamento,IBAN,cf);  
		COMMIT; 
		ELSE RAISE pagamento_invalido; 
        END IF; 
	END IF;  
	EXCEPTION 
        WHEN pagamento_invalido THEN 
ROLLBACK;
RAISE_APPLICATION_ERROR(-20006,'Errore, hai inserito dati per metodo di pagamento invalidi!'); 
	END; 

END INSERISCI_DATI_CLIENTE;
