CREATE OR REPLACE TRIGGER CLIENTE_MAGGIORENNE    
BEFORE INSERT OR UPDATE ON CLIENTI    
FOR EACH ROW    
DECLARE    
    cliente_minorenne EXCEPTION;    
BEGIN    
IF MONTHS_BETWEEN(SYSDATE,:new.datanascita)/12<18 THEN raise cliente_minorenne;    
END IF;    
EXCEPTION    
    WHEN cliente_minorenne THEN raise_application_error(-20003,'attenzione, sei minorenne, siamo spiacenti ma non puoi accedere al nostro servizio');    
END;