CREATE OR REPLACE TRIGGER CARTA_VALIDA  
BEFORE INSERT OR UPDATE ON CARTE  
FOR EACH ROW  
DECLARE  
    carta_scaduta EXCEPTION;  
BEGIN  
IF :new.scadenza<SYSDATE THEN raise carta_scaduta;  
END IF;  
EXCEPTION 	 
    WHEN carta_scaduta THEN raise_application_error(-20002,'la carta indicata è scaduta');  
END; 