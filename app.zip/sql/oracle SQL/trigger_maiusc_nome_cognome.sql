CREATE OR REPLACE TRIGGER MAIUSC_NOME_COGNOME   
BEFORE INSERT OR UPDATE ON CLIENTI   
FOR EACH ROW   
BEGIN   
:new.nome:=CONCAT(UPPER(SUBSTR(:new.nome,1,1)),LOWER(SUBSTR(:new.nome,2,LENGTH(:new.nome)-1)));   
:new.cognome:=CONCAT(UPPER(SUBSTR(:new.cognome,1,1)),LOWER(SUBSTR(:new.cognome,2,LENGTH(:new.cognome)-1)));   
END; 