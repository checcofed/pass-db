DROP TRIGGER IF EXISTS MAX_AUTO_ASSOCIATE_INSERT;
DROP TRIGGER IF EXISTS MAX_AUTO_ASSOCIATE_UPDATE;
DELIMITER $$

CREATE TRIGGER MAX_AUTO_ASSOCIATE_INSERT
BEFORE INSERT ON AUTOMOBILI
FOR EACH ROW
BEGIN
    DECLARE num_automobili INTEGER;

    SELECT COUNT(TARGA) INTO num_automobili
    FROM AUTOMOBILI
    WHERE dispositivo = NEW.dispositivo;

    IF num_automobili=2 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Il dispositivo specificato ha già due automobili associate, non è possibile inserirne altre';
    END IF;
END $$


CREATE TRIGGER MAX_AUTO_ASSOCIATE_UPDATE
BEFORE UPDATE ON AUTOMOBILI
FOR EACH ROW
BEGIN
    DECLARE num_automobili INTEGER;

    SELECT COUNT(TARGA) INTO num_automobili
    FROM AUTOMOBILI
    WHERE dispositivo = NEW.dispositivo;

    IF num_automobili=2 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Il dispositivo specificato ha già due automobili associate, non è possibile inserirne altre';
    END IF;
END $$

DELIMITER ;