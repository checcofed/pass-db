DROP TRIGGER IF EXISTS CLIENTE_DUPLICATO_CONTO_INSERT;
DROP TRIGGER IF EXISTS CLIENTE_DUPLICATO_CONTO_UPDATE;
DELIMITER $$

CREATE TRIGGER CLIENTE_DUPLICATO_CONTO_INSERT 
BEFORE INSERT ON CARTE    
FOR EACH ROW   
BEGIN 
DECLARE bufferCF VARCHAR(16);
DECLARE  cf_cursor CURSOR FOR SELECT CF FROM CLIENTI_CON_CONTO;  
DECLARE continue HANDLER FOR 1329 SET bufferCF:='none';  

OPEN cf_cursor;  
  
control_loop: LOOP 
    FETCH cf_cursor INTO bufferCF;  
	IF new.proprietariocarta=bufferCF THEN   
        CLOSE cf_cursor;  
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'cliente possiede già un conto, non è possibile inserire la carta';  
	END IF;   
	  
	IF bufferCF='none' then 
    leave control_loop; 
	END IF;
    
	END LOOP control_loop;  
  
CLOSE cf_cursor;  
END $$



CREATE TRIGGER CLIENTE_DUPLICATO_CONTO_UPDATE
BEFORE UPDATE ON CARTE    
FOR EACH ROW   
BEGIN 
DECLARE bufferCF VARCHAR(16);
DECLARE  cf_cursor CURSOR FOR SELECT CF FROM CLIENTI_CON_CONTO;  
DECLARE continue HANDLER FOR 1329 SET bufferCF:='none';  

OPEN cf_cursor;  
  
control_loop: LOOP 
    FETCH cf_cursor INTO bufferCF;  
	IF new.proprietariocarta=bufferCF THEN   
        CLOSE cf_cursor;  
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'cliente possiede già un conto, non è possibile inserire la carta';  
	END IF;   
	  
	IF bufferCF='none' then 
    leave control_loop; 
	END IF;
    
	END LOOP control_loop;  
  
CLOSE cf_cursor;  
END $$

