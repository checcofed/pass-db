DROP FUNCTION IF EXISTS ORARIO_PIU_TRAFFICATO;
DELIMITER $$


CREATE FUNCTION ORARIO_PIU_TRAFFICATO ()RETURNS CHAR(4)
READS SQL DATA   
BEGIN 
	DECLARE orario_ingresso CHAR(4); 
	DECLARE numero_ingressi INTEGER; 
	DECLARE orario_uscita CHAR(4); 
	DECLARE numero_uscite INTEGER; 
    BEGIN 
 
    select count(*)
	into numero_ingressi
    from tragitti
	group by (substr(data_ora_ingresso,12,2))
	having count(*)in(
		select max(tot) as massimo
		from (
			select count(*) as tot
			from tragitti
			group by(substr(data_ora_ingresso,12,2))
		) as num_tragitti
	);
         
    SELECT SUBSTR(data_ora_ingresso,12,2) INTO orario_ingresso 
    FROM TRAGITTI  
    GROUP BY (SUBSTR(data_ora_ingresso,12,2))  
    HAVING COUNT(*)=numero_ingressi; 
 
	select count(*)
    into numero_uscite
    from tragitti
    where data_ora_uscita is not null
	group by (substr(data_ora_uscita,12,2))
	having count(*)in(
		select max(tot) as massimo
		from (
			select count(*) as tot
			from tragitti
            where data_ora_uscita is not null
			group by(substr(data_ora_uscita,12,2))
		) as num_tragitti
	);
 
	SELECT SUBSTR(data_ora_uscita,12,2) INTO orario_uscita 
    FROM TRAGITTI  
    where data_ora_uscita is not null
    GROUP BY (SUBSTR(data_ora_uscita,12,2))
    HAVING COUNT(*)=numero_uscite; 
 
	IF numero_ingressi>numero_uscite THEN 
		RETURN orario_ingresso; 
	ELSE 
		RETURN orario_uscita; 
	END IF; 
	 
    END; 
END $$
