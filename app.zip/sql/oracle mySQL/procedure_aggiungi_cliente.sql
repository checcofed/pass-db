DROP PROCEDURE IF EXISTS INSERISCI_DATI_CLIENTI;
DELIMITER $$

CREATE PROCEDURE INSERISCI_DATI_CLIENTE(  
    cf  VARCHAR(16),   
    nome VARCHAR(30),   
	cognome VARCHAR(30),   
    datanascita DATE,
    codiceMetodoPagamento INTEGER,   
    IBAN VARCHAR(27),   
    scadenza DATE,   
    CVV INTEGER   
)
BEGIN 
    BEGIN  
    IF IBAN IS NULL AND scadenza IS NOT NULL AND CVV IS NOT NULL THEN 
        INSERT INTO CLIENTI VALUES(cf,nome,cognome,datanascita); 
		INSERT INTO CARTE VALUES(codiceMetodoPagamento,scadenza,CVV,cf); 
		COMMIT;      
    ELSE  
        IF IBAN IS NOT NULL AND scadenza IS NULL AND CVV IS NULL THEN 
        	INSERT INTO CLIENTI VALUES(cf,nome,cognome,datanascita); 
        	INSERT INTO CONTI VALUES(codiceMetodoPagamento,IBAN,cf);  
		COMMIT; 
		ELSE 
			ROLLBACK;            
        END IF; 
	END IF;  
	
	END; 

END $$
