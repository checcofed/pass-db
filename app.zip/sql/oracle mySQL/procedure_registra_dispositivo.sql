DROP PROCEDURE IF EXISTS REGISTRA_DISPOSITIVO;
DELIMITER $$

CREATE PROCEDURE REGISTRA_DISPOSITIVO( 
    codFiscaleInteressato VARCHAR(16), 
    targaAuto VARCHAR(10), 
    modelloAuto VARCHAR(30) 
) 
 
BEGIN  
	DECLARE nuovo_dispositivo INTEGER; 
	DECLARE buffer VARCHAR(10); 
	DECLARE insert_var BOOLEAN;
	DECLARE auto_cursor CURSOR FOR SELECT targa FROM AUTOMOBILI WHERE targaAuto=targa;
    DECLARE CONTINUE HANDLER FOR 1329 SET insert_var:=true;
    DECLARE CONTINUE HANDLER FOR 1048 SET nuovo_dispositivo:=1;
    
BEGIN 
    SELECT MAX(codice)+1 INTO nuovo_dispositivo FROM DISPOSITIVI; 
	INSERT INTO DISPOSITIVI VALUES (nuovo_dispositivo); 
	
	OPEN auto_cursor; 
	FETCH auto_cursor INTO buffer; 
 
	IF insert_var THEN 
		INSERT INTO AUTOMOBILI VALUES(targaAuto,modelloAuto,codFiscaleInteressato,nuovo_dispositivo); 
	ELSE 
        UPDATE AUTOMOBILI SET dispositivo=nuovo_dispositivo WHERE targa=targaAuto; 
	END IF; 
 
	COMMIT; 
	CLOSE auto_cursor;	 
	 
	END; 
END $$
