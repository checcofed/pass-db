DROP TRIGGER IF EXISTS CLIENTE_DUPLICATO_CARTA_INSERT;
DROP TRIGGER IF EXISTS CLIENTE_DUPLICATO_CARTA_UPDATE;
DELIMITER $$

CREATE TRIGGER CLIENTE_DUPLICATO_CARTA_INSERT
BEFORE INSERT ON CONTI   
FOR EACH ROW  
BEGIN
DECLARE bufferCF VARCHAR(16); 
DECLARE cf_cursor CURSOR FOR SELECT CF FROM CLIENTI_CON_CARTA; 
DECLARE CONTINUE HANDLER FOR 1329 SET bufferCF:='none';

OPEN cf_cursor; 
 
control_loop: LOOP 
    FETCH cf_cursor INTO bufferCF; 
	IF new.proprietarioconto=bufferCF THEN  
        CLOSE cf_cursor; 
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'cliente possiede già una carta, non è possibile inserire il conto';  
	END IF;  
	
    IF bufferCF='none' THEN LEAVE control_loop; 
    END IF;
	END LOOP control_loop; 
 
CLOSE cf_cursor; 
END $$

CREATE TRIGGER CLIENTE_DUPLICATO_CARTA_UPDATE
BEFORE UPDATE ON CONTI   
FOR EACH ROW  
BEGIN
DECLARE bufferCF VARCHAR(16); 
DECLARE cf_cursor CURSOR FOR SELECT CF FROM CLIENTI_CON_CARTA; 
DECLARE CONTINUE HANDLER FOR 1329 SET bufferCF:='none';

OPEN cf_cursor; 
 
control_loop: LOOP 
    FETCH cf_cursor INTO bufferCF; 
	IF new.proprietarioconto=bufferCF THEN  
        CLOSE cf_cursor; 
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'cliente possiede già una carta, non è possibile inserire il conto';  
	END IF;  
	
    IF bufferCF='none' THEN LEAVE control_loop; 
    END IF;
	END LOOP control_loop; 
 
CLOSE cf_cursor; 
END $$